﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChallengePostalCalculatorHelperMethod
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            double shipping = shippingTotal();

            resultLabel.Text = String.Format("Total cost to ship your package: {0:C}", shipping);
        }

        protected void widthTextBox_TextChanged(object sender, EventArgs e)
        {
            shippingTotal();
        }

        protected void lengthTextBox_TextChanged(object sender, EventArgs e)
        {
            shippingTotal();
        }

        protected void groundRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            shippingTotal();
        }

        protected void airRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            shippingTotal();
        }

        protected void nextDayRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            shippingTotal();

        }
        public void CalculateVolume(out int volume)
        {
            //calculate volume and create method

            int width = int.Parse(widthTextBox.Text);
            int height = int.Parse(heightTextBox.Text);
            int length = int.Parse(lengthTextBox.Text);

            volume = 0;
            if (widthTextBox.Text.Trim().Length == 0)
                return;
            if (!int.TryParse(widthTextBox.Text.Trim(), out width))
                return;
            if (!int.TryParse(heightTextBox.Text.Trim(), out height))
                return;
            if (!int.TryParse(lengthTextBox.Text.Trim(), out length)) length = 1;

            volume = (width * height * length);

        }

        //calculate shipping based on volume and ship type

        public double shippingTotal()
        {
            double shipping = 0;
            int volume = 0;
            if (groundRadioButton.Checked) return shipping = volume * .15;
            else if (airRadioButton.Checked) return shipping = volume * .25;
            else if (nextDayRadioButton.Checked) return shipping = volume * .45;
            return shipping; 
           

            

        }
        
      
        



    }     
 }
