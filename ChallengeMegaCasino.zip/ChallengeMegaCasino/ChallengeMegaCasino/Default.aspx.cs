﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChallengeMegaCasino
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)

            //set page_load images
            Image1.ImageUrl = "~/Plum.png";
            Image2.ImageUrl = "~/Clover.png";
            Image3.ImageUrl = "~/HorseShoe.png";

            //what is (moneyLabel) playersMoney amount
            double playersMoney = 100.0;
            moneyLabel.Text = String.Format("Players Money: {0:C}", playersMoney);  //need to assign variable

        }

        protected void leverButton_Click(object sender, EventArgs e)
        {
            //create betAmount from text box 
            if (betAmountTextBox.Text.Trim().Length == 0)
                resultLabel.Text = "Please enter a valid bet amount";

            //determine what betAmount is
            double betAmount = 0.0;
            if (!Double.TryParse(betAmountTextBox.Text.Trim(), out betAmount))
            {
                resultLabel.Text = "Please enter a valid amount.";
            }

            double playersMoney = 0.0;
            if (betAmount > playersMoney)
            {
                resultLabel.Text = "Please enter a bet amount less than or equal to your Players Money.";
            }
          
            else if (checkBar(betAmount))    //subtract bet from total
                return;
            else if (checkCherries(betAmount))   //adds money
                return;
            else if (checkJackpot(betAmount))     //100* betAmount
                return;
             if(double.Parse(moneyLabel.Text) == 0.0)     //want this to display resultLabel if players money is 0.
                {                                           // maybe not necessary??
                resultLabel.Text = "OOPS! No more money, please play again";
                }
        }
        //set random and create spinReel attach to images
        Random random = new Random();

        private string spinReel(Random random)
        {
            string[] images = new string[12] {"Strawberry","Bar","Lemon","Bell","Clover","Cherry","Diamond",
                "Orange","Seven","HorseShoe","Plum","Watermellon"};
            return images [random.Next(12)];

                Image1.ImageUrl = images[random.Next(12)];
                Image2.ImageUrl = images[random.Next(12)];
                Image3.ImageUrl = images[random.Next(12)];
        }

        //create method for playersMoney
        private double playersMoney(double betAmount)
        {
            double playersMoney = 0.0;
            double totalMoney = playersMoney - betAmount;
            return totalMoney;
        }

        //create method to checkBar
        private bool checkBar(double betAmount)
        {
            
            if (Image1.ImageUrl == "Bar" || Image2.ImageUrl == "Bar" || Image3.ImageUrl == "Bar")
                return true;
                {
                double totalMoney = 0.0;
                moneyLabel.Text = totalMoney.ToString();
                resultLabel.Text = String.Format("Sorry, you lost {0:C}. Better luck next time!", betAmount);
                }
                return true;  
        }

        //create method to checkCherries
        private bool checkCherries(double betAmount)
        {
            double winnings = 0.0;
            if (Image1.ImageUrl == "Cherry"|| Image2.ImageUrl == "Cherry" || Image3.ImageUrl == "Cherry")
            {
                winnings = betAmount * 2;
            }
            if (Image1.ImageUrl == "Cherry" && Image2.ImageUrl == "Cherry" 
                || Image1.ImageUrl == "Cherry" && Image3.ImageUrl == "Cherry" 
                || Image3.ImageUrl == "Cherry" && Image3.ImageUrl == "Cherry")
            {
                winnings = betAmount * 3;
            }
            if (Image1.ImageUrl == "Cherry" && Image2.ImageUrl == "Cherry" && Image3.ImageUrl == "Cherry")
            {
                winnings = betAmount * 4;
            }
            resultLabel.Text = String.Format("You bet {0:C}, and won {1:C}!", betAmount, winnings);

            return true;
        }

        //create method to checkJackpot
        private bool checkJackpot(double betAmount)
        {
            double winnings = 0.0;
            if (Image1.ImageUrl == "Seven"
                && Image2.ImageUrl == "Seven"
                && Image3.ImageUrl == "Seven")
            {
                winnings = betAmount * 100;
                resultLabel.Text = String.Format("You bet {0:C}, and won {1:C}!", betAmount, winnings);
            }
            return true;

        }
        //create method for subtractBet from playerMoney
        //resultLabel display wins or losses


    }
}