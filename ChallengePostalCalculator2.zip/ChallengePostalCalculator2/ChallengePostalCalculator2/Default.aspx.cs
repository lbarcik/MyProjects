﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChallengePostalCalculator2
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        

        private double CalculateVolume()
        {
            //calculate volume and create method

           
            double width = 0;
            double height = 0;
            double length = 0;

           /* width = double.Parse(widthTextBox.Text);
            height = double.Parse(heightTextBox.Text);
            length = double.Parse(lengthTextBox.Text);*/

            double volume = (width * height * length);

            if (widthTextBox.Text.Trim().Length == 0)
                return 0;
            if (!Double.TryParse(widthTextBox.Text.Trim(), out width))
                return width;
            if (!Double.TryParse(heightTextBox.Text.Trim(), out height))
                return height;
            if (!Double.TryParse(lengthTextBox.Text.Trim(), out length)) length = 1;
                return length;    
        }

        public double shippingTotal(out double shippingCost)
        {

            double shipping = 0;
            if (groundRadioButton.Checked)
                shipping = .15;
            else if (airRadioButton.Checked)
                shipping = .25;
            else if (nextDayRadioButton.Checked)
                shipping = .45;
            return shipping; //I cannot figure out where this goes! 
        }
          private void calculateTotal(double shipping, double volume)
        {
            double shippingCost = shipping * volume;
            resultLabel.Text = String.Format("Total cost to ship your package: {0:C}", shippingCost);
        }

            protected void widthTextBox_TextChanged(object sender, EventArgs e)
            {
                calculateTotal(double shipping, double volume);
            }


            protected void heightTextBox_TextChanged(object sender, EventArgs e)
            {
                calculateTotal(double shipping, double volume);
            }

            protected void lengthTextBox_TextChanged(object sender, EventArgs e)
            {
                calculateTotal(double shipping, double volume);
            }

            protected void groundRadioButton_CheckedChanged(object sender, EventArgs e)
            {
                calculateTotal(double shipping, double volume);
            }

            protected void airRadioButton_CheckedChanged(object sender, EventArgs e)
            {
                calculateTotal(double shipping, double volume);
            }

            protected void nextDayRadioButton_CheckedChanged(object sender, EventArgs e)
            {
                calculateTotal(double shipping, double volume);
            }

        }


        

    }
}
   