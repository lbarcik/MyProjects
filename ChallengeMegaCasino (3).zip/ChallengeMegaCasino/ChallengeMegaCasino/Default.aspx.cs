﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChallengeMegaCasino
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {



            int totalMoney = 100;                          
            moneyLabel.Text = String.Format("Players Money: {0:C}", totalMoney);   //determine what playersMoney starts with
            int betAmount = 0;
            if (!int.TryParse(betAmountTextBox.Text.Trim(), out betAmount)) return;

            pullLever(betAmount);                                                 //Bob suggested this goes here

            resultLabel.Text = String.Format("You bet {0:C}!", betAmount);        //displays bet amount

            //string reels = "";      
            //checkBar(betAmount,reels);      
            //checkCherries(betAmount,reels);
            //checkJackpot(betAmount, reels);

            
           // playersMoney(betAmount); had this here but put it under leverButton. 

          /* !!!! This subtracts the betAmount from the total and displays properly but does not continue to 
                  calculate nor factor in winnings. My check Methods below are not doing any thing. I did attempt to put below 
                  in the leverButton() but it did nothing. 
            int gameTotal = 0;
            int winnings = 0;
            gameTotal = totalMoney - betAmount + winnings;
            resultLabel.Text = String.Format("You bet {0:C}, and won {1:C}!", betAmount, winnings);
            moneyLabel.Text = String.Format("Players Money: {0:C}", gameTotal);
            return;
          */

        }
        protected void leverButton_Click(object sender, EventArgs e)
        {
            //create betAmount from text box
            if (betAmountTextBox.Text.Trim().Length == 0)
                resultLabel.Text = "Please place a bet";

            int totalMoney = 0;
            int betAmount = 0;
            if (betAmount > totalMoney)
            {
                resultLabel.Text = "Please enter a bet amount less than or equal to your Players Money.";
            }
            if (betAmount <= totalMoney) return;
        }

        //set random and create spinReel attach to images
        private void pullLever(int betAmount)
        {
            string[] reels = new string[] { spinReel(), spinReel(), spinReel() };
            displayImages(reels);
        }
        //set images to display
        private void displayImages(string[] reels)
        {
            Image1.ImageUrl = "/Images/" + reels[0] + ".png";
            Image2.ImageUrl = "/Images/" + reels[1] + ".png";
            Image3.ImageUrl = "/Images/" + reels[2] + ".png";
        }
        //create spin
        Random random = new Random();
        private string spinReel()
        {
            string[] images = new string[12] {"Strawberry","Bar","Lemon","Bell","Clover","Cherry","Diamond",
            "Orange","Seven","HorseShoe","Plum","Watermellon"};
            return images[random.Next(12)];
        }

        //create method to checkBar
        private bool checkBar(int betAmount, string reels)
        {

            if (Image1.ImageUrl == "Bar" || Image2.ImageUrl == "Bar" || Image3.ImageUrl == "Bar")
            {

                int totalMoney = 0;
                totalMoney = betAmount * 0;
                resultLabel.Text = String.Format("Sorry, you lost {0:C}. Better luck next time!", betAmount);
                return true;
            }
            else return false;
        }

        //create method to checkCherries
        private bool checkCherries(int betAmount, string reels)
        {
            int winnings = 0;
            if (Image1.ImageUrl == "Cherry" || Image2.ImageUrl == "Cherry" || Image3.ImageUrl == "Cherry")
            {
                winnings = betAmount * 2;
                resultLabel.Text = String.Format("You bet {0:C}, and won {1:C}!", betAmount, winnings);
                return true;
            }
            if (Image1.ImageUrl == "Cherry" && Image2.ImageUrl == "Cherry"
                || Image1.ImageUrl == "Cherry" && Image3.ImageUrl == "Cherry"
                || Image3.ImageUrl == "Cherry" && Image3.ImageUrl == "Cherry")
            {
                winnings = betAmount * 3;
                resultLabel.Text = String.Format("You bet {0:C}, and won {1:C}!", betAmount, winnings);
                return true;
            }
            if (Image1.ImageUrl == "Cherry" && Image2.ImageUrl == "Cherry" && Image3.ImageUrl == "Cherry")
            {
                winnings = betAmount * 4;
                resultLabel.Text = String.Format("You bet {0:C}, and won {1:C}!", betAmount, winnings);
                return true;
            }
            else return false;
        }

        //create method to checkJackpot
        private bool checkJackpot(int betAmount, string reels)
        {
            int winnings = 0;
            if (Image1.ImageUrl == "Seven"
                && Image2.ImageUrl == "Seven"
                && Image3.ImageUrl == "Seven")
            {
                winnings = betAmount * 100;
                resultLabel.Text = String.Format("You bet {0:C}, and won {1:C}!", betAmount, winnings);
                return true;
            }
            else return false;

        }
        
        //create playersMoney
         private int playersMoney(int betAmount)
         {
            int totalMoney = 0;
            int gameTotal = 0;
            int winnings = 0;
            gameTotal = totalMoney - betAmount + winnings;
            resultLabel.Text = String.Format("You bet {0:C}, and won {1:C}!", betAmount, winnings);
            moneyLabel.Text = String.Format("Players Money: {0:C}", gameTotal);
            return gameTotal;
        }
        

    }
}