﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChallengeMegaCasino
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            
                int totalMoney = 100;
                moneyLabel.Text = String.Format("Players Money: {0:C}", totalMoney);
                //determine what betAmount is
                int betAmount = 0;
                if (!int.TryParse(betAmountTextBox.Text.Trim(), out betAmount)) return;

                pullLever(betAmount);


            
        }
        protected void leverButton_Click(object sender, EventArgs e)
        {
            //create betAmount from text box 
            if (betAmountTextBox.Text.Trim().Length == 0)
                resultLabel.Text = "Please place a bet";

            int totalMoney = 0;
            int betAmount = 0;
            if (betAmount > totalMoney)
            {
                resultLabel.Text = "Please enter a bet amount less than or equal to your Players Money.";
            }
            if (betAmount <= totalMoney) return;

            string reels = ""; 
            checkBar(betAmount,reels);
            checkCherries(betAmount,reels);
            checkJackpot(betAmount,reels);

            playersMoney(betAmount);
             
            /*
            else if (checkBar(betAmount))    //subtract bet from total
                return;
            else if (checkCherries(betAmount))   //adds money
                return;
            else if (checkJackpot(betAmount))     //100* betAmount
                return;
            else 
            */
        }


        //set random and create spinReel attach to images
        private void pullLever(int betAmount)
        {
            string[] reels = new string[] { spinReel(), spinReel(), spinReel() };
            displayImages(reels);
        }
        
        //will return an integer, needed to pass in reels so that it knows 
       // private int evaluateSpin(reels)
       // {

       // }

        private void displayImages(string[] reels)
        {
            Image1.ImageUrl = "/Images/" + reels[0] + ".png";
            Image2.ImageUrl = "/Images/" + reels[1] + ".png";
            Image3.ImageUrl = "/Images/" + reels[2] + ".png";
        }
        Random random = new Random();
        private string spinReel()
        {
            string[] images = new string[12] {"Strawberry","Bar","Lemon","Bell","Clover","Cherry","Diamond",
            "Orange","Seven","HorseShoe","Plum","Watermellon"};
            return images[random.Next(12)];    
        }

        //create method to checkBar
        private bool checkBar(int betAmount, string reels)
        {

            if (Image1.ImageUrl == "Bar" || Image2.ImageUrl == "Bar" || Image3.ImageUrl == "Bar")
            {

                int totalMoney = 0;
                totalMoney = betAmount * 0;
                resultLabel.Text = String.Format("Sorry, you lost {0:C}. Better luck next time!", totalMoney);
                return true;
            }
            else return false;
        }

        //create method to checkCherries
        private bool checkCherries(int betAmount, string reels)
        {
            int winnings = 0;
            if (Image1.ImageUrl == "Cherry" || Image2.ImageUrl == "Cherry" || Image3.ImageUrl == "Cherry")
            {
                winnings = betAmount * 2;
                resultLabel.Text = String.Format("You bet {0:C}, and won {1:C}!", betAmount, winnings);
                return true;
            }
            if (Image1.ImageUrl == "Cherry" && Image2.ImageUrl == "Cherry"
                || Image1.ImageUrl == "Cherry" && Image3.ImageUrl == "Cherry"
                || Image3.ImageUrl == "Cherry" && Image3.ImageUrl == "Cherry")
            {
                winnings = betAmount * 3;
                resultLabel.Text = String.Format("You bet {0:C}, and won {1:C}!", betAmount, winnings);
                return true;
            }
            if (Image1.ImageUrl == "Cherry" && Image2.ImageUrl == "Cherry" && Image3.ImageUrl == "Cherry")
            {
                winnings = betAmount * 4;
                resultLabel.Text = String.Format("You bet {0:C}, and won {1:C}!", betAmount, winnings);
                return true;
            }
            else return false;
            }


        //create method to checkJackpot
        private bool checkJackpot(int betAmount, string reels)
        {
            int winnings = 0;
            if (Image1.ImageUrl == "Seven"
                && Image2.ImageUrl == "Seven"
                && Image3.ImageUrl == "Seven")
            {
                winnings = betAmount * 100;
                resultLabel.Text = String.Format("You bet {0:C}, and won {1:C}!", betAmount, winnings);
                return true;
            }
            else return false;

        }

        //create method for playersMoney
        private int playersMoney(int betAmount)
        {
            int totalMoney = 0;
            int winnings = 0;
            int gameTotal = totalMoney - betAmount + winnings;

            moneyLabel.Text = String.Format("Players Money: {0:C}", gameTotal);
            return gameTotal;
        }






        //create method for subtractBet from playerMoney
        //resultLabel display wins or losses


    }
}